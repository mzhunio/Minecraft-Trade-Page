<script setup lang="ts">

</script>

<template>
 
 <div class="container mt-5">
 <div class="card">
  
  <div class="card-content">
    <div class="media">
      <div class="media-left">
        <figure class="image is-48x48">
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIAAYAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQEDBgIAB//EADUQAAIBAwMBBQYFBAMBAAAAAAECAwAEERIhMQUTIkFRYQYycYGRoRRCscHwI2LR4UNy8SX/xAAYAQADAQEAAAAAAAAAAAAAAAABAgMABP/EAB4RAAMBAQADAQEBAAAAAAAAAAABEQIhAxIxIkET/9oADAMBAAIRAxEAPwD6mKnNRXqckBX3UYrOWOJwWd98DwHnV8E0dxGHibI+4pF7QoT1CNi2nEQ73zNTYysmJInRiOdJxqHqKi/I1osvGnlD6oIqIpFljWRDlW4rrGapaT+EYxUHiuqhmCgsxwByaxipyFUsxAA5Jqgyxyg9mwOOaqL/AIl9X/GPdH70PG2OpaBwYzn7VH/TvCy8fHTqcbUquxTibg0puxzVCZrs16oFTVCQl9pYswLLxsUPp4/tSLp11EAAJRrO2FY7/UfvWi9ph/8AIlfDEREO2nyHNZjpVqjqHjBZck6zvgenjiob4zp8buR90meZGkV9lY5UE8GnaMmn3iTttSJItKu6tkINTY329KZdPlWV4Lj8kyd3P1H89KVNrgzyn0KkwveJOPSgL4zONIIK53AoyBxIkkT+8kuAfQ15kBLKOVODQ020ZZSdFodRGAvveAzXFhHqmeUkHSuNvU/6o9rZHRsnRt7w/Sq4oUjV9HDHOflWyuoOnMspn4NKrzg00m8aWXfBqpA1Ga9qrjVUZqrJizr90gh/DOcCX3vhSo3ll0yBu1kMUEa51aTgD5UB1y7ZutlSSdDBQPDFaq2/C9W6ZLayoqCRMBsZwRx9/CoafszoyvXIv6Z1rpt4zwpLouJoz2ayo0bN8NQGa7sL9GSzs2LJPHgFfHak/tF0O6S9u74W8k8Ulr2SRxJ2mGzkMCOCPA7cVT0SS5urLptzdow6jGQk4bkkY3PypGhsumxjRkmkdvcMgar55li7YsT32wqhSSR47CiOnACJHkHc5zSa8a8nWOTTLHILwSh4xkPGr5A9MqNJzWhtaYbbXtrMpVGZWBwySKVI+tXXEKomU92h7Us7XE9wqdrOwxGpB0KBtn15NGTELEyHbbIo54wa6hRMOaWXfBpnOeaV3fBqpIcz30MBId9x4CqB1i0LaWk0n+6sXf8AUnLZDapG9aFjuC+7vkcd6kfmd4OvCp0Ze0Ok9ReWJ10kA5wCK76V1YWzhbiQx/3Fcg/LNVq2qNWkGx8QOBUy2Mr47OaRQT+TBFSdtLZkhrLDqYkUt2mzD83iKWozL12NMLocbY896Ds2SKFY2Zmc5DEA7fEqT9xRE/Sxf4VLowzrq7KQMDpPqDyP8U1YIqbWFM2zxDvOBsM1RN05gRke7t6GhfZxZZZWkvnaN4joC5A1EcmnusNKS3u+jZFFfpVi6/LiFEarAd17wPFeuZTIpJA+VTMyySsSW05qqb3MDjzrL6Zvgvnpbd8GmU/jSu6OxqpExZHaksSSCdzVsRRQMjccCuZmCqcZAG1dWCmWfYE4GdxxXMdI/ERltwgjDZGB8aFjguYdUbsZ0J91wBpz4U0s43UB0UOpG6tUzdlK8USgKzA7ryoHOfShtsbAnEnY3OhUaLww2MEeh8KedMUyMpE3dIxhf5xVa9KRFPad+N31doTk06sbBF20Y8MY8MVPLdH0lA20ghtxr/EMhPhqyTXct6hBTUxHhvzQ00CREa172CMYzmgnYj3QCc7HeqvbJrIwN2W2XG23G9WgmSBgw43FCqyRIHkwSRz411bzGYsB7uDg8Vsa6DWVAafbOKV3XBrz9SOso48fAVDf1xtqHyq3uiHqzDu4kkXJ7xOSPhT3p6KoBVcZAzgbmreo+xJ7UXFi4yvEbHY1XHHJYyKlzEyk8DO1TkLWjq3mMOlWGpW8Rjb+fGiRAJDrjwSgzkDf0pSLhywVYNWrYZbfFWp1H8EcNDNhedCg/XilaoVwbxGaLRqGoEgH1o0XPZkZRu/6eVJLL2htdaLddrGWHdLpwc8HFPo54pkVkYMCMagc70vqN7Fd3eM8Gv5qQNwaUxXErtKqpq2455/8+9OymGbUDgsCSR4eQqtFRZ5ZFQKvAHn61nlsy0kAW9vPKirKWULuM0dMewsZyhyRGd/PaunIyG2IA86X9b6jDa2DoSoaTuqCcE58qbOYLrVEVuvulV0s3AA3Jo5NQbSCc/mYfoD9PvQNlcLoICBdSnBzyMef14zx4UbGyY2LHWQANZyd/jx8PvihTQ0+mZSMLqB8+efP/VVXNvBdI0V1HkNthhtz51yEiV2lRY1kYAMyjvYGRjj6DFXRSnOgsjjcZBO3G21UokMvd9GvekzNd2Je7t+SjnU8Q/t8x96tinFxbLKFCxkZ8yf91o4mjMhVcptnBPh50k6z0uW2c3lkNSZ1SwAZP/ZR+1Y1A54o5Y8jHaH6g/5pl0spEqI3vLgZ4Ioe1EFxbhoWVgQMMDVigQoZJTgDfPy3oQNGNzOYgFJAQrtS2Xqw7Zo4f6jnbPgKvZB1GyaGQlFbBVhyPWgZbNYXFtEFi0b97fI/egwome/nht5ZZkVQoJznIrEC8uOpXkk80j6Ce4jNtprc3lr+L6fPCje/ER86xkCi3hWPGnOAD5Nny86GqkHP0OiyoZVBwScYA7oG3l6/bnwphaiSedtABxkamJbQAfTB48seHON1cKCUFmxj8pz7w/xx9KPhmIUw2z6WcYdlI7mcEZzwdwePOkQzNjr0rqzo2OkMuS2+Bwc+R2+1dq6qhCydpyNIOTkHGN/XahipVldg47/af02OGGnABXb4aRnfBq3tAZjpGrQdOCpIwPjjkfIY8aqIWyd8MdT6lGFbbIPz+fpVsUuG7OT4g558f3FBxvlFw+dWN43Gkkbnx38TxRHZ9rGwMfZtz3sHGDzzWAZ3q8Q6T1mO4iXs7a7JEngA/gfiePpV80TXDRCJsDGphq25pze9PgvrP8JeHXFKpG+AR5Eeu+2KU2kLdGmis75zIZXCRT4x2vx8iKKV4ChNmroVTTsDgfD+Zr3X7QyxQy5wR3TjyouIIjl5OMjUQOK59opre26cjXEmgLKpXJxk5plkHtBV09Zox2Mrhtu9twaV+1NhCv4aeIaXd9DAAb/zFEN1hJXYWSNcMBk6OM+GW49fOh5EuLqRZb11BTOhI9wPM0mkkoMn/RYVkkbSuEiUBcryfPHlv4/pzR0MTxKNC7k5CNhc+pOOO9nOOaIjt1UxrD2elWGUI5H8/SiijsdUrgFhwv8ATXJ4w3lgetIkPT//2Q==" alt="Placeholder image">
        </figure>
      </div>
      <div class="media-content">
        <p class="title is-4">Mr Cat</p>
        <p class="subtitle is-6">@kitty</p>
      </div>
    </div>

    <div class="content">
      Hi my name is Mr. Cat, and I would like to trade minecraft items. Please take a look at my list. 
    </div>
    
        <div class="tabs is-left">
  <ul>
    <li class="is-active"><a>List of Trades</a>
    </li>
    <li><a>Messages</a></li>
    <li><a>Search</a></li>
  </ul>
</div>
    
  </div>
</div>
</div>

</template>

<style scoped>

</style>