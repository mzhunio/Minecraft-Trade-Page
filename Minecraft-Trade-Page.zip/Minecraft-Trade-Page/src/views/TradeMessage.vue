<script setup lang="ts"></script>

<template>Messages</template>

<style scoped></style>
