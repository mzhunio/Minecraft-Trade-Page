export interface CategoryItem {
    id: number;
    name: string;
    category: string;
    image: string;
}