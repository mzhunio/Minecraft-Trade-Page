<template>
    <hr/>
    <div class="footercomp mt-4 p-4">
    <h1 class="is-size-4	">IMPORTANT LINKS: </h1>
      <a href="https://github.com/CastilByrdr/Minecraft-Trade-Page">Front-End Github Repository</a><br>
      <a href="https://github.com/gfzhunio/Minecraft-Trade-Page-API">Back-End Github Repository</a>
    </div>
 </template>
   
<style scoped>
.footercomp {
   background-color: rgb(105, 172, 235);
}
a {
    color: white;
}
</style>